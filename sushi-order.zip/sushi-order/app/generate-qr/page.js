'use client';

import { useState } from 'react';
import { supabase } from '../../lib/supabaseClient';

const INITIAL_FORM = { tableNumber: '', adultCount: '', childCount: '' };

function minutesSince(createdAt) {
  const created = new Date(createdAt).getTime();
  const now = Date.now();
  const diffMinutes = Math.max(0, Math.round((now - created) / 60000));
  return diffMinutes;
}

export default function GenerateQrPage() {
  const [form, setForm] = useState(INITIAL_FORM);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Existing open session blocking the new one
  const [conflict, setConflict] = useState(null); // { id, adult_count, child_count, created_at }
  const [showConfirmClose, setShowConfirmClose] = useState(false);
  const [closing, setClosing] = useState(false);

  // Result of a freshly opened table
  const [result, setResult] = useState(null); // { tableNumber, adultCount, childCount, url }

  const [copied, setCopied] = useState(false);

  function handleChange(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  function resetAll() {
    setForm(INITIAL_FORM);
    setConflict(null);
    setShowConfirmClose(false);
    setResult(null);
    setErrorMessage('');
    setCopied(false);
  }

  async function handleOpenTable(e) {
    e.preventDefault();
    setErrorMessage('');

    const tableNumber = parseInt(form.tableNumber, 10);
    const adultCount = parseInt(form.adultCount, 10) || 0;
    const childCount = parseInt(form.childCount, 10) || 0;

    if (!form.tableNumber || Number.isNaN(tableNumber)) {
      setErrorMessage('กรุณากรอกเลขโต๊ะให้ถูกต้อง');
      return;
    }

    setLoading(true);
    try {
      // 1) Check for an existing open session on this table.
      const { data: existing, error: checkError } = await supabase
        .from('sessions')
        .select('id, adult_count, child_count, created_at')
        .eq('table_number', tableNumber)
        .eq('status', 'open')
        .limit(1)
        .maybeSingle();

      if (checkError) throw checkError;

      if (existing) {
        setConflict(existing);
        setLoading(false);
        return;
      }

      // 2) No open session — create a new one.
      const { error: insertError } = await supabase.from('sessions').insert({
        table_number: tableNumber,
        adult_count: adultCount,
        child_count: childCount,
        status: 'open',
      });

      if (insertError) throw insertError;

      const origin =
        typeof window !== 'undefined' ? window.location.origin : '';
      const url = `${origin}/order/${tableNumber}`;

      setResult({
        tableNumber,
        adultCount,
        childCount,
        url,
      });
    } catch (err) {
      setErrorMessage(err.message || 'เกิดข้อผิดพลาด กรุณาลองใหม่');
    } finally {
      setLoading(false);
    }
  }

  async function handleConfirmCloseOld() {
    if (!conflict) return;
    setClosing(true);
    setErrorMessage('');
    try {
      // Re-check status = 'open' at update time to guard against double-clicks
      // or another employee having already closed it.
      const { data, error } = await supabase
        .from('sessions')
        .update({ status: 'closed' })
        .eq('id', conflict.id)
        .eq('status', 'open')
        .select('id');

      if (error) throw error;

      if (!data || data.length === 0) {
        setErrorMessage(
          'โต๊ะนี้ถูกปิดไปแล้วโดยผู้อื่น กรุณากด "เปิดโต๊ะ" อีกครั้ง'
        );
      }

      setShowConfirmClose(false);
      setConflict(null);
      // Form values remain; employee presses "เปิดโต๊ะ" again to start new session.
    } catch (err) {
      setErrorMessage(err.message || 'ปิดโต๊ะเดิมไม่สำเร็จ กรุณาลองใหม่');
    } finally {
      setClosing(false);
    }
  }

  async function handleCopyLink() {
    if (!result) return;
    try {
      await navigator.clipboard.writeText(result.url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setErrorMessage('คัดลอกลิงก์ไม่สำเร็จ กรุณาคัดลอกด้วยตนเอง');
    }
  }

  const qrSrc = result
    ? `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(
        result.url
      )}`
    : null;

  return (
    <main style={styles.main}>
      <h1 style={styles.heading}>เปิดโต๊ะ</h1>

      {errorMessage && !conflict && !result && (
        <div style={styles.errorBanner}>{errorMessage}</div>
      )}

      {/* RESULT: fresh QR for the newly opened table */}
      {result && (
        <div style={styles.resultBox}>
          <img
            src={qrSrc}
            alt={`QR สำหรับโต๊ะ ${result.tableNumber}`}
            width={300}
            height={300}
            style={styles.qrImage}
          />
          <p style={styles.summaryText}>
            โต๊ะ {result.tableNumber} · ผู้ใหญ่ {result.adultCount} · เด็ก{' '}
            {result.childCount}
          </p>
          <div style={styles.linkRow}>
            <span style={styles.linkText}>{result.url}</span>
            <button
              type="button"
              onClick={handleCopyLink}
              style={styles.copyButton}
            >
              {copied ? 'คัดลอกแล้ว ✓' : 'คัดลอกลิงก์'}
            </button>
          </div>
          <button
            type="button"
            onClick={resetAll}
            style={styles.primaryButton}
          >
            เปิดโต๊ะใหม่
          </button>
        </div>
      )}

      {/* WARNING: table already has an open session */}
      {!result && conflict && (
        <div style={styles.warningBox}>
          <p style={styles.warningTitle}>
            โต๊ะนี้มีลูกค้าอยู่ระหว่างทานอาหาร กรุณาปิดออเดอร์เดิมก่อน
          </p>
          <p style={styles.warningDetail}>
            โต๊ะ {form.tableNumber} · ผู้ใหญ่ {conflict.adult_count} · เด็ก{' '}
            {conflict.child_count}
          </p>
          <p style={styles.warningDetail}>
            เปิดมาแล้ว {minutesSince(conflict.created_at)} นาที
          </p>
          <button
            type="button"
            onClick={() => setShowConfirmClose(true)}
            style={styles.dangerButton}
          >
            ปิดออเดอร์เดิม
          </button>
          {errorMessage && (
            <div style={styles.errorBannerInline}>{errorMessage}</div>
          )}
        </div>
      )}

      {/* CONFIRM DIALOG for closing the old session */}
      {showConfirmClose && conflict && (
        <div style={styles.overlay}>
          <div style={styles.confirmBox}>
            <h2 style={styles.confirmHeading}>ยืนยันปิดโต๊ะเดิม</h2>
            <p style={styles.confirmDetail}>เลขโต๊ะ: {form.tableNumber}</p>
            <p style={styles.confirmDetail}>
              ผู้ใหญ่ {conflict.adult_count} · เด็ก {conflict.child_count}
            </p>
            <p style={styles.confirmDetail}>
              เปิดมาแล้ว {minutesSince(conflict.created_at)} นาที
            </p>
            <div style={styles.confirmButtonRow}>
              <button
                type="button"
                onClick={() => setShowConfirmClose(false)}
                style={styles.secondaryButton}
                disabled={closing}
              >
                ยกเลิก
              </button>
              <button
                type="button"
                onClick={handleConfirmCloseOld}
                style={styles.dangerButton}
                disabled={closing}
              >
                {closing ? 'กำลังปิด...' : 'ยืนยันปิดโต๊ะเดิม'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FORM: only shown when there's no result and no active conflict warning */}
      {!result && !conflict && (
        <form onSubmit={handleOpenTable} style={styles.form}>
          <label style={styles.label}>
            เลขโต๊ะ
            <input
              type="number"
              inputMode="numeric"
              value={form.tableNumber}
              onChange={(e) => handleChange('tableNumber', e.target.value)}
              style={styles.input}
              required
            />
          </label>
          <label style={styles.label}>
            จำนวนผู้ใหญ่
            <input
              type="number"
              inputMode="numeric"
              min="0"
              value={form.adultCount}
              onChange={(e) => handleChange('adultCount', e.target.value)}
              style={styles.input}
            />
          </label>
          <label style={styles.label}>
            จำนวนเด็ก
            <input
              type="number"
              inputMode="numeric"
              min="0"
              value={form.childCount}
              onChange={(e) => handleChange('childCount', e.target.value)}
              style={styles.input}
            />
          </label>

          <button
            type="submit"
            disabled={loading}
            style={styles.primaryButton}
          >
            {loading ? 'กำลังเปิดโต๊ะ...' : 'เปิดโต๊ะ'}
          </button>
        </form>
      )}
    </main>
  );
}

const styles = {
  main: {
    minHeight: '100vh',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: '2rem 1.5rem',
    fontFamily: 'sans-serif',
    gap: '1.5rem',
  },
  heading: {
    fontSize: '2.25rem',
    margin: 0,
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1.25rem',
    width: '100%',
    maxWidth: '360px',
  },
  label: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.5rem',
    fontSize: '1.25rem',
    fontWeight: 600,
  },
  input: {
    fontSize: '1.5rem',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '2px solid #ccc',
  },
  primaryButton: {
    fontSize: '1.5rem',
    padding: '1rem',
    borderRadius: '10px',
    border: 'none',
    background: '#111',
    color: '#fff',
    cursor: 'pointer',
  },
  secondaryButton: {
    fontSize: '1.25rem',
    padding: '0.9rem 1.25rem',
    borderRadius: '10px',
    border: '2px solid #999',
    background: '#fff',
    color: '#333',
    cursor: 'pointer',
  },
  dangerButton: {
    fontSize: '1.25rem',
    padding: '0.9rem 1.25rem',
    borderRadius: '10px',
    border: 'none',
    background: '#d32f2f',
    color: '#fff',
    cursor: 'pointer',
    fontWeight: 700,
  },
  warningBox: {
    width: '100%',
    maxWidth: '420px',
    background: '#fff3e0',
    border: '3px solid #f57c00',
    borderRadius: '12px',
    padding: '1.5rem',
    display: 'flex',
    flexDirection: 'column',
    gap: '0.75rem',
  },
  warningTitle: {
    fontSize: '1.4rem',
    fontWeight: 700,
    color: '#c62828',
    margin: 0,
  },
  warningDetail: {
    fontSize: '1.15rem',
    margin: 0,
    color: '#333',
  },
  errorBanner: {
    width: '100%',
    maxWidth: '420px',
    background: '#ffebee',
    border: '2px solid #d32f2f',
    color: '#b71c1c',
    borderRadius: '10px',
    padding: '1rem',
    fontSize: '1.1rem',
  },
  errorBannerInline: {
    background: '#ffebee',
    border: '2px solid #d32f2f',
    color: '#b71c1c',
    borderRadius: '10px',
    padding: '0.75rem',
    fontSize: '1rem',
  },
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '1.5rem',
    zIndex: 50,
  },
  confirmBox: {
    background: '#fff',
    borderRadius: '14px',
    border: '3px solid #d32f2f',
    padding: '2rem',
    width: '100%',
    maxWidth: '400px',
    display: 'flex',
    flexDirection: 'column',
    gap: '0.75rem',
  },
  confirmHeading: {
    fontSize: '1.5rem',
    margin: 0,
    color: '#c62828',
  },
  confirmDetail: {
    fontSize: '1.15rem',
    margin: 0,
  },
  confirmButtonRow: {
    display: 'flex',
    gap: '1rem',
    marginTop: '1rem',
  },
  resultBox: {
    width: '100%',
    maxWidth: '360px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '1rem',
  },
  qrImage: {
    borderRadius: '12px',
    border: '2px solid #ddd',
  },
  summaryText: {
    fontSize: '1.4rem',
    fontWeight: 700,
    margin: 0,
    textAlign: 'center',
  },
  linkRow: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  linkText: {
    fontSize: '1rem',
    color: '#333',
    wordBreak: 'break-all',
  },
  copyButton: {
    fontSize: '0.95rem',
    padding: '0.4rem 0.75rem',
    borderRadius: '8px',
    border: '2px solid #111',
    background: '#fff',
    color: '#111',
    cursor: 'pointer',
    whiteSpace: 'nowrap',
  },
};
