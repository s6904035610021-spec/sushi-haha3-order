import Link from 'next/link';

export default function HomePage() {
  return (
    <main
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '1.5rem',
        fontFamily: 'sans-serif',
        textAlign: 'center',
        padding: '2rem',
      }}
    >
      <h1 style={{ fontSize: '2rem', margin: 0 }}>🍣 ร้านซูชิ</h1>
      <p style={{ margin: 0, color: '#555' }}>
        ระบบสั่งอาหารออนไลน์ เชื่อมต่อกับ Supabase
      </p>
      <nav style={{ display: 'flex', gap: '1rem' }}>
        <Link
          href="/generate-qr"
          style={{
            padding: '0.75rem 1.5rem',
            borderRadius: '8px',
            background: '#111',
            color: '#fff',
            textDecoration: 'none',
          }}
        >
          สร้าง QR โต๊ะ
        </Link>
        <Link
          href="/kitchen"
          style={{
            padding: '0.75rem 1.5rem',
            borderRadius: '8px',
            border: '1px solid #111',
            color: '#111',
            textDecoration: 'none',
          }}
        >
          หน้าครัว
        </Link>
      </nav>
    </main>
  );
}
