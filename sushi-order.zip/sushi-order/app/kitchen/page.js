export default function KitchenPage() {
  return (
    <main style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>หน้าครัว</h1>
      <p>หน้านี้จะใช้แสดงออเดอร์ที่เข้ามาแบบเรียลไทม์จากตาราง orders ใน Supabase</p>
    </main>
  );
}
