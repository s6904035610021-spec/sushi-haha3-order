# ระบบสั่งอาหารร้านซูชิ

Next.js (App Router, JavaScript) + Supabase, deploy บน Vercel

## ติดตั้ง

```bash
npm install
cp .env.local.example .env.local   # แล้วกรอกค่า Supabase ของจริง
npm run dev
```

## Environment variables (ตั้งใน Vercel Project Settings → Environment Variables ด้วย)

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

## โครงสร้างฐานข้อมูล Supabase (มีอยู่แล้ว ไม่ต้องสร้างใหม่)

อ้างอิงเดียวกันทั้งโปรเจกต์นี้:

- **sessions** — `id, table_number, adult_count, child_count, status, created_at`
- **menu_categories** — `id, name, sort_order`
- **menu_items** — `id, category_id, name`
- **orders** — `id, session_id, table_number, items (jsonb), status, created_at`

## หน้าที่มีในโครง

- `/` — หน้าแรก แสดงชื่อร้านและลิงก์ทดสอบ
- `/generate-qr` — (placeholder) สร้าง QR โต๊ะ / สร้าง session
- `/kitchen` — (placeholder) แสดงออเดอร์แบบเรียลไทม์
